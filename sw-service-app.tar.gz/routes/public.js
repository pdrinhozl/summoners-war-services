const express = require('express');
const { get, all, run } = require('../db/db');
const { requireLogin } = require('../middleware');
const requestUpload = require('../lib/request-upload');
const { notify } = require('../lib/notify');
const router = express.Router();

router.get('/', (req, res) => {
  if (res.locals.user) return res.redirect('/painel');
  const base = `SELECT s.*, c.name AS category_name, c.icon AS category_icon, c.color AS category_color
                FROM services s JOIN categories c ON c.id = s.category_id`;
  const featured = all(`${base} WHERE s.status = 'approved' AND s.featured = 1 ORDER BY s.approved_at DESC LIMIT 6`);
  const latest = all(`${base} WHERE s.status = 'approved' ORDER BY s.approved_at DESC LIMIT 6`);
  const catStats = all(
    `SELECT c.id, c.name, c.slug, c.icon, c.color, COUNT(s.id) AS total
     FROM categories c LEFT JOIN services s ON s.category_id = c.id AND s.status = 'approved'
     GROUP BY c.id ORDER BY c.sort, c.name`
  );
  const sellerCount = get("SELECT COUNT(*) AS n FROM users WHERE role = 'seller' AND seller_status = 'verified'").n;
  const quoteCount = get('SELECT COUNT(*) AS n FROM quotes').n;
  res.render('index', { featured, latest, catStats, sellerCount, quoteCount, _categories: all('SELECT id, name FROM categories') });
});

router.get('/services', (req, res) => {
  const { cat, q, sort } = req.query;
  const params = [];
  let where = "s.status = 'approved'";
  if (cat && cat !== 'all') {
    where += ' AND c.slug = ?';
    params.push(cat);
  }
  if (q) {
    where += ' AND (s.title LIKE ? OR s.short LIKE ?)';
    params.push(`%${q}%`, `%${q}%`);
  }
  const order = sort === 'price_asc' ? 's.price_from ASC' : sort === 'price_desc' ? 's.price_from DESC' : 's.featured DESC, s.approved_at DESC';
  const services = all(
    `SELECT s.*, c.name AS category_name, c.slug AS category_slug, c.icon AS category_icon, c.color AS category_color, u.name AS seller_name
     FROM services s JOIN categories c ON c.id = s.category_id JOIN users u ON u.id = COALESCE(s.seller_id, (SELECT id FROM users WHERE role = 'admin' LIMIT 1))
     WHERE ${where} ORDER BY ${order}`,
    params
  );
  const activeCat = cat || 'all';
  const counts = {};
  for (const c of res.locals.categories) {
    counts[c.slug] = all("SELECT COUNT(*) AS n FROM services s JOIN categories c2 ON c2.id = s.category_id WHERE s.status = 'approved' AND c2.slug = ?", [c.slug])[0].n;
  }
  res.render('services', { services, activeCat, q: q || '', sort: sort || 'newest', counts });
});

router.get('/services/:slug', (req, res) => {
  const service = get(
    `SELECT s.*, c.name AS category_name, c.slug AS category_slug, c.icon AS category_icon, c.color AS category_color,
            u.name AS seller_name, u.seller_status AS seller_status
     FROM services s JOIN categories c ON c.id = s.category_id
     JOIN users u ON u.id = COALESCE(s.seller_id, (SELECT id FROM users WHERE role = 'admin' LIMIT 1))
     WHERE s.slug = ? AND s.status = 'approved'`,
    [req.params.slug]
  );
  if (!service) return res.status(404).render('erro', { code: 404, title: 'Serviço não encontrado', message: 'Este serviço não existe ou não está mais disponível.' });
  let includes = [];
  try { includes = JSON.parse(service.includes || '[]'); } catch (_e) { includes = []; }
  const related = all(
    `SELECT * FROM services WHERE category_id = ? AND id != ? AND status = 'approved' LIMIT 3`,
    [service.category_id, service.id]
  );
  res.render('service', { service, includes, related });
});

function requestForm(req, res, values = {}, error = '') {
  const services = all("SELECT id, title, category_id FROM services WHERE status = 'approved' ORDER BY title");
  const preselect = Number(values.service_id || req.query.service) ||
    (req.query.slug ? (get("SELECT id FROM services WHERE slug = ? AND status = 'approved'", [req.query.slug]) || {}).id : null);
  const selected = services.find(s => s.id === preselect);
  const requestedSeller = get("SELECT id, name FROM users WHERE id = ? AND role = 'seller' AND seller_status = 'verified' AND active = 1", [Number(values.requested_seller_id || req.query.prestador) || 0]);
  res.status(error ? 422 : 200).render('orcamento', { services, preselect: preselect || null,
    values: { category_id: selected ? selected.category_id : req.query.category, ...values }, error, requestedSeller });
}

router.get('/orcamento', requireLogin, (req, res) => requestForm(req, res));
router.get('/solicitar', (req, res) => res.redirect('/orcamento'));

router.post('/orcamento', requireLogin, (req, res, next) => {
  const b = req.body || {};
  const str = v => String(v || '').trim();
  const user = res.locals.user;
  const service = b.service_id ? get("SELECT * FROM services WHERE id = ? AND status = 'approved'", [Number(b.service_id) || 0]) : null;
  const category = get('SELECT * FROM categories WHERE id = ?', [Number(b.category_id || (service && service.category_id)) || 0]);
  if (b.service_id && !service) return requestForm(req, res, b, 'Este serviço não está mais disponível. Escolha outro.');
  if (!category) return requestForm(req, res, b, 'Selecione a categoria do serviço.');
  if (service && service.category_id !== category.id) return requestForm(req, res, b, 'Escolha um serviço da categoria selecionada.');
  if (str(b.message).length < 10 || str(b.message).length > 2000) return requestForm(req, res, b, 'Descreva o que você precisa usando de 10 a 2.000 caracteres.');
  if (b.priority && !['normal', 'high'].includes(b.priority)) return requestForm(req, res, b, 'Selecione uma prioridade válida.');
  const seller = b.requested_seller_id ? get("SELECT id FROM users WHERE id = ? AND role = 'seller' AND seller_status = 'verified' AND active = 1", [Number(b.requested_seller_id) || 0]) : null;
  if (b.requested_seller_id && !seller) return requestForm(req, res, b, 'Este prestador não está disponível.');
  let attachment;
  try { attachment = requestUpload.save(req.file); } catch (err) { return next(err); }
  const result = run(`INSERT INTO quotes (client_id, service_id, client_name, client_email, client_whatsapp, game_name,
    game_level, game_rank, game_boxes, message, account_ready, category_id, priority, attachment, requested_seller_id)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [user.id, service ? service.id : null, user.name, user.email, str(b.client_whatsapp || user.phone).slice(0, 30),
      str(b.game_name).slice(0, 80), str(b.game_level).slice(0, 20), str(b.game_rank).slice(0, 80),
      str(b.game_boxes).slice(0, 200), str(b.message), b.account_ready ? 1 : 0, category.id,
      b.priority || 'normal', attachment, seller ? seller.id : null]);
  const id = Number(result.lastInsertRowid);
  for (const admin of all("SELECT id FROM users WHERE role = 'admin' AND active = 1")) {
    notify(admin.id, `Nova solicitação #${id}: ${user.name}`, `/admin/orcamentos/${id}`);
  }
  const provider = seller ? seller.id : service && service.seller_id;
  if (provider) notify(provider, `Nova solicitação #${id}. Aguardando análise da equipe.`, '/vendedor/orcamentos');
  req.session.flash = [{ type: 'success', text: 'Solicitação enviada! Acompanhe seu orçamento aqui.' }];
  res.redirect(`/cliente/orcamentos/${id}`);
});

router.get('/orcamento/sucesso/:id', requireLogin, (req, res) => {
  const quote = get('SELECT id FROM quotes WHERE id = ? AND client_id = ?', [req.params.id, res.locals.user.id]);
  if (!quote) return res.status(404).render('erro', { code: 404, title: 'Solicitação não encontrada', message: 'Confira suas solicitações no painel.' });
  res.redirect(`/cliente/orcamentos/${quote.id}`);
});

router.get('/como-funciona', (req, res) => {
  res.render('como-funciona');
});

router.get('/seja-um-vendedor', (req, res) => {
  res.render('seja-vendedor');
});

router.get('/termos', (req, res) => {
  res.render('termos');
});

router.get('/privacidade', (req, res) => {
  res.render('privacidade');
});

router.get('/robots.txt', (req, res) => {
  const base = res.locals.baseUrl;
  res.type('text/plain').send(`User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /vendedor\nDisallow: /cliente\nDisallow: /login\nDisallow: /registro\nSitemap: ${base}/sitemap.xml\n`);
});

router.get('/sitemap.xml', (req, res) => {
  const base = res.locals.baseUrl;
  const now = new Date().toISOString().slice(0, 10);
  const urls = ['', '/services', '/como-funciona', '/seja-um-vendedor', '/orcamento', '/termos', '/privacidade'];
  const services = all("SELECT slug, created_at FROM services WHERE status = 'approved'");
  let xml = '<?xml version="1.0" encoding="UTF-8"?>\n';
  xml += '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n';
  for (const u of urls) {
    xml += `  <url><loc>${base}${u}</loc><lastmod>${now}</lastmod><changefreq>weekly</changefreq><priority>0.8</priority></url>\n`;
  }
  for (const sv of services) {
    const lastmod = sv.created_at ? sv.created_at.slice(0, 10) : now;
    xml += `  <url><loc>${base}/services/${sv.slug}</loc><lastmod>${lastmod}</lastmod><changefreq>weekly</changefreq><priority>0.7</priority></url>\n`;
  }
  xml += '</urlset>';
  res.type('application/xml').send(xml);
});

module.exports = router;