const { test } = require('node:test');
const assert = require('node:assert/strict');
const { spawnSync } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');

test('produção mantém dados no volume e protege o primeiro acesso', () => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'sw-production-'));
  const env = {
    ...process.env,
    NODE_ENV: 'production',
    DATA_DIR: directory,
    DB_PATH: path.join(directory, 'app.db'),
    UPLOAD_DIR: path.join(directory, 'uploads'),
    ATTACHMENT_DIR: path.join(directory, 'attachments'),
    SESSION_SECRET: crypto.randomBytes(32).toString('hex'),
    INITIAL_ADMIN_EMAIL: 'owner@example.test',
    INITIAL_ADMIN_PASSWORD: crypto.randomBytes(24).toString('hex'),
  };
  function run(code, overrides = {}) {
    return spawnSync(process.execPath, ['-e', code], {
      cwd: path.join(__dirname, '..'), env: { ...env, ...overrides }, encoding: 'utf8', timeout: 15000,
    });
  }
  try {
    const insecure = run("require('./server')", { SESSION_SECRET: '' });
    assert.notEqual(insecure.status, 0);
    assert.match(insecure.stderr, /SESSION_SECRET/);
    const bootstrap = run(`
      const assert = require('node:assert/strict');
      const fs = require('node:fs');
      const path = require('node:path');
      const bcrypt = require('bcryptjs');
      const { get, run, DATA_DIR } = require('./db/db');
      (async () => {
        await require('./db/seed')();
        const admin = get('SELECT * FROM users WHERE role = ?', ['admin']);
        assert.equal(bcrypt.compareSync(process.env.INITIAL_ADMIN_PASSWORD, admin.password), true);
        assert.equal(bcrypt.compareSync('admin123', admin.password), false);
        assert.equal(get('SELECT COUNT(*) AS n FROM users').n, 1);
        run('UPDATE users SET password = ? WHERE id = ?', [bcrypt.hashSync('ChangedPasswordForTest!', 10), admin.id]);
        run('INSERT INTO settings (key, value) VALUES (?, ?)', ['persistence_test', 'saved']);
        fs.mkdirSync(process.env.UPLOAD_DIR, { recursive: true });
        fs.writeFileSync(path.join(process.env.UPLOAD_DIR, 'proof.txt'), 'persistent upload');
        assert.equal(DATA_DIR, process.env.DATA_DIR);
      })().catch(e => { console.error(e); process.exit(1); });
    `);
    assert.equal(bootstrap.status, 0, bootstrap.stderr);
    const restart = run(`
      const assert = require('node:assert/strict');
      const bcrypt = require('bcryptjs');
      const { get } = require('./db/db');
      (async () => {
        await require('./db/seed')();
        assert.equal(get('SELECT COUNT(*) AS n FROM users').n, 1);
        const admin = get('SELECT * FROM users WHERE role = ?', ['admin']);
        assert.equal(bcrypt.compareSync('ChangedPasswordForTest!', admin.password), true);
        assert.equal(get('SELECT value FROM settings WHERE key = ?', ['persistence_test']).value, 'saved');
        const { app } = require('./server');
        const server = app.listen(0, '127.0.0.1', async () => {
          try {
            const base = 'http://127.0.0.1:' + server.address().port;
            const health = await fetch(base + '/health');
            assert.equal(health.status, 200);
            assert.equal((await health.json()).status, 'ok');
            assert.equal(await (await fetch(base + '/uploads/proof.txt')).text(), 'persistent upload');
            const login = await fetch(base + '/login', { headers: { 'x-forwarded-proto': 'https' } });
            assert.match(login.headers.get('set-cookie'), /Secure/);
          } catch (e) { console.error(e); process.exitCode = 1; }
          finally { server.close(); }
        });
      })().catch(e => { console.error(e); process.exit(1); });
    `, { INITIAL_ADMIN_PASSWORD: crypto.randomBytes(24).toString('hex') });
    assert.equal(restart.status, 0, restart.stderr);
  } finally {
    fs.rmSync(directory, { recursive: true, force: true });
  }
});
