const express = require('express');
const path = require('path');
const bcrypt = require('bcryptjs');
const QRCode = require('qrcode');
const { get, all, run } = require('../db/db');
const { requireLogin } = require('../middleware');
const { directory } = require('../lib/request-upload');
const { notify } = require('../lib/notify');
const router = express.Router();

const notFound = res => res.status(404).render('erro', { code: 404, title: 'Não encontrado', message: 'Este item não está disponível para sua conta.' });
const flash = (req, type, text) => { req.session.flash = [{ type, text }]; };

router.get('/cliente/orcamentos/:id', requireLogin, (req, res) => {
  const quote = get(`SELECT q.*, s.title AS service_title, c.name AS category_name, c.icon AS category_icon,
    u.name AS seller_name FROM quotes q LEFT JOIN services s ON s.id = q.service_id
    LEFT JOIN categories c ON c.id = COALESCE(q.category_id, s.category_id)
    LEFT JOIN users u ON u.id = COALESCE(q.requested_seller_id, s.seller_id)
    WHERE q.id = ? AND q.client_id = ?`, [req.params.id, res.locals.user.id]);
  if (!quote) return notFound(res);
  const order = get('SELECT id FROM orders WHERE quote_id = ?', [quote.id]);
  if (order) return res.redirect(`/cliente/pedidos/${order.id}`);
  res.render('client/orcamento-detalhe', { quote });
});

router.post('/cliente/orcamentos/:id/:action(cancelar|ajustar)', requireLogin, (req, res) => {
  const quote = get('SELECT * FROM quotes WHERE id = ? AND client_id = ?', [req.params.id, res.locals.user.id]);
  if (!quote) return notFound(res);
  const order = get('SELECT id FROM orders WHERE quote_id = ?', [quote.id]);
  if (order) return res.redirect(`/cliente/pedidos/${order.id}`);
  if (['cancelled', 'done', 'rejected'].includes(quote.status)) {
    flash(req, 'error', 'Esta solicitação já foi encerrada.');
    return res.redirect(`/cliente/orcamentos/${quote.id}`);
  }
  if (req.params.action === 'cancelar') {
    run("UPDATE quotes SET status = 'cancelled', updated_at = datetime('now') WHERE id = ?", [quote.id]);
    flash(req, 'success', 'Solicitação cancelada.');
  } else {
    const message = String(req.body.message || '').trim();
    if (quote.status !== 'approved' || message.length < 5 || message.length > 1000) {
      flash(req, 'error', 'Escreva o ajuste desejado, de 5 a 1.000 caracteres, para um orçamento recebido.');
      return res.redirect(`/cliente/orcamentos/${quote.id}`);
    }
    run("UPDATE quotes SET status = 'pending', adjustment_note = ?, offer_price = NULL, updated_at = datetime('now') WHERE id = ?", [message, quote.id]);
    flash(req, 'success', 'Ajuste solicitado. Aguarde a nova proposta.');
  }
  for (const admin of all("SELECT id FROM users WHERE role = 'admin' AND active = 1")) {
    notify(admin.id, `Solicitação #${quote.id}: ${req.params.action === 'cancelar' ? 'cancelada pelo cliente' : 'ajuste solicitado'}.`, `/admin/orcamentos/${quote.id}`);
  }
  res.redirect(`/cliente/orcamentos/${quote.id}`);
});

router.get('/anexos/solicitacoes/:id', requireLogin, (req, res) => {
  const quote = get(`SELECT q.*, s.seller_id FROM quotes q LEFT JOIN services s ON s.id = q.service_id WHERE q.id = ?`, [req.params.id]);
  const u = res.locals.user;
  const assigned = quote && get('SELECT id FROM orders WHERE quote_id = ? AND seller_id = ?', [quote.id, u.id]);
  const authorizedSeller = u.role === 'seller' && u.seller_status === 'verified' && quote && (quote.seller_id === u.id || quote.requested_seller_id === u.id || assigned);
  if (!quote || !quote.attachment || !(quote.client_id === u.id || u.role === 'admin' || authorizedSeller)) return notFound(res);
  res.set('Cache-Control', 'private, no-store');
  res.sendFile(path.join(directory, path.basename(quote.attachment)), err => { if (err && !res.headersSent) notFound(res); });
});

router.get('/cliente/pedidos/:id/pagamento', requireLogin, async (req, res, next) => {
  const order = get('SELECT * FROM orders WHERE id = ? AND client_id = ?', [req.params.id, res.locals.user.id]);
  if (!order) return notFound(res);
  if (order.status !== 'pending_payment') return res.redirect(`/cliente/pedidos/${order.id}`);
  try {
    const qr = order.payment_code ? await QRCode.toDataURL(order.payment_code, { width: 260, margin: 2 }) : null;
    res.render('client/pagamento', { order, qr });
  } catch (err) { next(err); }
});

router.get('/perfil', requireLogin, (req, res) => res.render('client/perfil', { error: '', values: res.locals.user }));
router.post('/perfil', requireLogin, (req, res) => {
  const u = res.locals.user;
  const name = String(req.body.name || '').trim();
  const phone = String(req.body.phone || '').trim();
  const error = name.length < 2 || name.length > 80 ? 'Informe um nome de 2 a 80 caracteres.'
    : phone && !/^[+()\d\s-]{8,30}$/.test(phone) ? 'Confira o número de WhatsApp.' : '';
  if (error) return res.status(422).render('client/perfil', { error, values: { ...u, name, phone } });
  run('UPDATE users SET name = ?, phone = ? WHERE id = ?', [name, phone, u.id]);
  flash(req, 'success', 'Perfil atualizado.');
  res.redirect('/perfil');
});
router.post('/perfil/senha', requireLogin, (req, res) => {
  const u = res.locals.user;
  const { current_password, password, password2 } = req.body;
  if (!bcrypt.compareSync(String(current_password || ''), u.password)) {
    flash(req, 'error', 'Sua senha atual não confere.');
  } else if (!password || password.length < 8 || password.length > 72 || password !== password2) {
    flash(req, 'error', 'Use de 8 a 72 caracteres e confirme a mesma senha.');
  } else {
    run('UPDATE users SET password = ? WHERE id = ?', [bcrypt.hashSync(password, 10), u.id]);
    flash(req, 'success', 'Senha alterada.');
  }
  res.redirect('/perfil');
});

router.get('/notificacoes', requireLogin, (req, res) => {
  const items = all('SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 100', [res.locals.user.id]);
  res.render('client/notificacoes', { items });
});
router.post('/notificacoes/:id/abrir', requireLogin, (req, res) => {
  const item = get('SELECT * FROM notifications WHERE id = ? AND user_id = ?', [req.params.id, res.locals.user.id]);
  if (!item) return notFound(res);
  run('UPDATE notifications SET read = 1 WHERE id = ?', [item.id]);
  const link = item.link && /^\/(?!\/)/.test(item.link) && !item.link.includes('\\') ? item.link : '/notificacoes';
  res.redirect(link);
});

router.get('/suporte', (_req, res) => res.render('suporte'));
router.get('/prestadores/:id', (req, res) => {
  const seller = get("SELECT id, name, seller_about, seller_rating, seller_review_count FROM users WHERE id = ? AND role = 'seller' AND seller_status = 'verified' AND active = 1", [req.params.id]);
  if (!seller) return notFound(res);
  const completed = get("SELECT COUNT(*) AS n FROM orders WHERE seller_id = ? AND status = 'completed'", [seller.id]).n;
  const reviews = all(`SELECT r.rating, r.comment, r.created_at, u.name AS client_name FROM reviews r
    LEFT JOIN users u ON u.id = r.client_id WHERE r.seller_id = ? ORDER BY r.id DESC LIMIT 30`, [seller.id]);
  const services = all("SELECT s.*, c.name AS category_name, c.icon AS category_icon FROM services s LEFT JOIN categories c ON c.id = s.category_id WHERE s.seller_id = ? AND s.status = 'approved'", [seller.id]);
  res.render('prestador', { seller, completed, reviews, services });
});

module.exports = router;
