document.addEventListener('DOMContentLoaded', function () {
  // Keep copy behavior available to existing administration screens as well.
  document.querySelectorAll('[data-copy]').forEach(function (button) {
    button.addEventListener('click', async function () {
      var original = button.textContent;
      var copied = false;
      try {
        if (navigator.clipboard && window.isSecureContext) {
          await navigator.clipboard.writeText(button.dataset.copy);
          copied = true;
        } else {
          var area = document.createElement('textarea');
          area.value = button.dataset.copy;
          area.style.position = 'fixed'; area.style.top = '0';
          document.body.appendChild(area); area.select();
          copied = document.execCommand('copy'); area.remove();
        }
      } catch (_e) { copied = false; }
      button.textContent = copied ? 'Código copiado!' : 'Selecione o código e copie manualmente';
      button.setAttribute('aria-live', 'polite');
      setTimeout(function () { button.textContent = original; }, 3500);
    });
  });
  document.querySelectorAll('.data-table').forEach(function (table) {
    var headings = table.querySelectorAll('thead th');
    table.querySelectorAll('tbody tr').forEach(function (row) {
      row.querySelectorAll('td').forEach(function (cell, i) {
        if (headings[i]) cell.dataset.label = headings[i].textContent.trim();
      });
    });
  });
  document.querySelectorAll('input[type=file][name=image]').forEach(function (input) {
    input.addEventListener('change', function () {
      if (!input.files[0]) return;
      var reader = new FileReader();
      reader.onload = function (event) {
        var img = input.parentElement.querySelector('.thumb') || document.createElement('img');
        img.src = event.target.result; img.className = 'thumb'; img.alt = 'Prévia da imagem';
        if (!img.parentElement) input.parentElement.appendChild(img);
      };
      reader.readAsDataURL(input.files[0]);
    });
  });
  document.addEventListener('submit', function (event) {
    var form = event.target;
    if (event.defaultPrevented || form.method.toLowerCase() === 'get') return;
    if (form.dataset.confirm && !window.confirm(form.dataset.confirm)) { event.preventDefault(); return; }
    if (form.dataset.submitting) { event.preventDefault(); return; }
    form.dataset.submitting = 'true'; form.setAttribute('aria-busy', 'true');
    // Preserve named submit button values used by administrative actions.
    var button = event.submitter;
    if (button) { button.setAttribute('aria-disabled', 'true'); button.classList.add('is-submitting'); }
  });
  window.addEventListener('pageshow', function () {
    document.querySelectorAll('form[data-submitting]').forEach(function (form) {
      delete form.dataset.submitting; form.removeAttribute('aria-busy');
      form.querySelectorAll('[aria-disabled]').forEach(function (button) { button.removeAttribute('aria-disabled'); button.classList.remove('is-submitting'); });
    });
  });
});
