document.addEventListener('DOMContentLoaded', function () {
  var menu = document.querySelector('[data-menu-toggle]');
  var sidebar = document.getElementById('appSidebar');
  function toggleMenu(open) {
    document.body.classList.toggle('nav-open', open);
    if (menu) menu.setAttribute('aria-expanded', String(open));
    if (open && sidebar) { var link = sidebar.querySelector('a'); if(link) link.focus(); }
    if (!open && menu) menu.focus();
  }
  if (menu) menu.addEventListener('click', function () { toggleMenu(!document.body.classList.contains('nav-open')); });
  document.querySelectorAll('[data-menu-close]').forEach(function (button) { button.addEventListener('click', function () { toggleMenu(false); }); });
  document.addEventListener('keydown', function (event) {
    if (!document.body.classList.contains('nav-open')) return;
    if (event.key === 'Escape') toggleMenu(false);
    if (event.key === 'Tab') {
      var focusable = sidebar.querySelectorAll('a,button');
      var first = focusable[0]; var last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }
  });
  document.querySelectorAll('[data-toggle-password]').forEach(function (button) {
    button.addEventListener('click', function () {
      var input = document.getElementById(button.dataset.togglePassword);
      var show = input.type === 'password'; input.type = show ? 'text' : 'password';
      button.setAttribute('aria-label', show ? 'Ocultar senha' : 'Mostrar senha');
      button.setAttribute('aria-pressed', String(show));
    });
  });
  document.querySelectorAll('[data-counter]').forEach(function (input) {
    var count = document.getElementById(input.dataset.counter);
    function update() { if(count) count.textContent = input.value.length + '/' + input.maxLength; }
    input.addEventListener('input', update); update();
  });
  var attachment = document.getElementById('attachment');
  var preview = document.getElementById('attachmentPreview');
  var remove = document.getElementById('removeAttachment');
  var attachmentLabel = document.getElementById('attachmentLabel');
  var previewUrl = '';
  function resetAttachment() {
    if(previewUrl) URL.revokeObjectURL(previewUrl);
    previewUrl = ''; attachment.value = ''; preview.hidden = true; preview.removeAttribute('src'); remove.hidden = true;
    attachmentLabel.textContent = 'Toque para adicionar uma imagem';
  }
  if (attachment) {
    attachment.addEventListener('change', function () {
      var file = attachment.files[0];
      if (!file) { resetAttachment(); return; }
      if (file.size > 4 * 1024 * 1024 || !['image/png','image/jpeg','image/webp'].includes(file.type)) {
        attachment.setCustomValidity('Escolha uma imagem JPG, PNG ou WebP de até 4 MB.'); attachment.reportValidity();
        resetAttachment(); attachment.setCustomValidity(''); return;
      }
      if(previewUrl) URL.revokeObjectURL(previewUrl);
      previewUrl = URL.createObjectURL(file); preview.src = previewUrl; preview.hidden = false; remove.hidden = false;
      attachmentLabel.textContent = file.name;
    });
    remove.addEventListener('click', resetAttachment);
  }
  var category = document.getElementById('category');
  var service = document.getElementById('service');
  if (category && service) {
    function filterServices() {
      Array.from(service.options).forEach(function (option) { option.hidden = !!option.value && !!category.value && option.dataset.category !== category.value; });
      if (service.selectedOptions[0] && service.selectedOptions[0].hidden) service.value = '';
    }
    category.addEventListener('change', filterServices);
    service.addEventListener('change', function () {
      if(service.value) category.value = service.selectedOptions[0].dataset.category;
      filterServices();
    });
    filterServices();
  }
  document.querySelectorAll('input[name=role]').forEach(function (input) {
    input.addEventListener('change', function () { var note = document.querySelector('[data-seller-note]'); if(note) note.hidden = input.value !== 'seller'; });
  });
  // Improve labeling on legacy management forms without changing their field names.
  document.querySelectorAll('.field').forEach(function (field, index) {
    var label = field.querySelector('label'); var input = field.querySelector('input:not([type=hidden]),select,textarea');
    if(label && input && !label.htmlFor) { if(!input.id) input.id = 'field-' + index; label.htmlFor = input.id; }
  });
});
